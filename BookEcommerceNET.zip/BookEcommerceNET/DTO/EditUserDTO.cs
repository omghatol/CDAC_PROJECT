﻿namespace BookEcommerceNET.DTO
{
    public class EditUserDTO
    {
        public string? UserName { get; set; }
        public string? Email { get; set; }
        public string? Contact { get; set; }
        public string? Pincode { get; set; }
        public string? Address { get; set; }
    }
}
