﻿namespace BookEcommerceNET.DTO
{
    public class PaymentRequestDTO
    {
        public long OrderId { get; set; }
        public double Amount { get; set; }
    }

}
