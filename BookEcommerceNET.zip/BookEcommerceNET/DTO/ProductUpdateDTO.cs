﻿namespace BookEcommerceNET.DTO
{
    public class ProductUpdateDTO
    {
        public double Price { get; set; }
        public double Quantity { get; set; }
    }
}
