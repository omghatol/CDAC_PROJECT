﻿namespace BookEcommerceNET.Models
{
    public enum Role
    {
        ROLE_ADMIN, ROLE_CUSTOMER, ROLE_SELLER
    }
}
